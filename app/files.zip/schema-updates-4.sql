-- ============================================================
-- تعديلات لوحة تحكم الإدارة (Admin Panel)
-- شغّل الملف ده في Supabase SQL Editor بعد باقي ملفات الـ schema
-- (schema-updates.sql, schema-updates-2.sql, schema-updates-3.sql)
-- ============================================================

-- 1) عمود يحدد إن المستخدم أدمن أو لأ
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;

-- 2) أعمدة تفعيل/تعطيل (لو مش موجودة أصلاً) — مفيدة للوحة التحكم
ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_available BOOLEAN DEFAULT TRUE;

-- ============================================================
-- Helper function: بترجع true لو المستخدم الحالي أدمن.
-- SECURITY DEFINER عشان الدالة تقدر تقرا جدول users حتى لو الشخص
-- نفسه مش عنده صلاحية يقرا صف غير صفه (RLS)، من غير ما نعمل حلقة
-- لا نهائية في الـ policy.
-- ============================================================
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_admin FROM public.users WHERE id = auth.uid()),
    FALSE
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ============================================================
-- Policies إضافية تدي الأدمن صلاحية كاملة (SELECT/INSERT/UPDATE/DELETE)
-- على كل الجداول. دي بتتضاف جنب الـ policies العادية اللي عملناها
-- قبل كده للمستخدم العادي (مش بتشيلها، Postgres بيدمجهم بـ OR)
-- ============================================================

DROP POLICY IF EXISTS "الأدمن يدير المطاعم" ON restaurants;
CREATE POLICY "الأدمن يدير المطاعم"
  ON restaurants FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يدير المنتجات" ON products;
CREATE POLICY "الأدمن يدير المنتجات"
  ON products FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يدير كل الطلبات" ON orders;
CREATE POLICY "الأدمن يدير كل الطلبات"
  ON orders FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يدير كل الطلبات الفرعية" ON sub_orders;
CREATE POLICY "الأدمن يدير كل الطلبات الفرعية"
  ON sub_orders FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يدير كل عناصر الطلبات" ON order_items;
CREATE POLICY "الأدمن يدير كل عناصر الطلبات"
  ON order_items FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يدير كل المستخدمين" ON users;
CREATE POLICY "الأدمن يدير كل المستخدمين"
  ON users FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "الأدمن يشوف كل العناوين" ON addresses;
CREATE POLICY "الأدمن يشوف كل العناوين"
  ON addresses FOR SELECT USING (is_admin());

-- ============================================================
-- مهم جدًا: بعد ما تشغّل الملف ده، حط نفسك أدمن يدويًا (مرة واحدة بس).
-- استبدل الإيميل بإيميلك اللي سجّلت بيه في التطبيق:
-- ============================================================
-- UPDATE users SET is_admin = true
-- WHERE id = (SELECT id FROM auth.users WHERE email = 'your-email@example.com');
